package com.example.myloginregisterapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.TextView;

public class RegisterActivity extends AppCompatActivity {

    private TextView username, email, password, confirmPass;
    private boolean usernameHasError, emailHasError, passwordHasError, confirmPassHasError = Boolean.FALSE;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_register);
        TextView btn= findViewById(R.id.existingAccount);

        username = findViewById(R.id.inputUserName);
        email = findViewById(R.id.inputEmail);
        password = findViewById(R.id.inputPassword);
        confirmPass = findViewById(R.id.inputConfirmPassword);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(RegisterActivity.this, LoginActivity.class));
            }
        });

        username.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                String userNm = charSequence.toString();

                if (userNm != null && userNm.length() > 5) {
                    username.setError(null);
                    usernameHasError =  Boolean.FALSE;
                } else {
                    username.setError("Invalid Username");
                    usernameHasError =  Boolean.TRUE;
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        email.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                String emailContent = charSequence.toString();

                if (emailContent != null && emailContent.length() > 5) {
                    email.setError(null);
                    emailHasError =  Boolean.FALSE;
                } else {
                    email.setError("Invalid Username");
                    emailHasError =  Boolean.TRUE;
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        password.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                String pass = charSequence.toString();
                String passConf = confirmPass.toString();

                if (passConf != null && pass != null && passConf.length() > 5) {

                    if (pass.matches(passConf)) {
                        confirmPass.setError(null);
                        confirmPassHasError =  Boolean.FALSE;
                    } else {
                        confirmPass.setError("Passwords do not match");
                        confirmPassHasError =  Boolean.TRUE;
                    }

                } else {
                    confirmPass.setError("Please fill this field");
                    confirmPassHasError =  Boolean.TRUE;
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        confirmPass.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                String passConf = charSequence.toString();
                String pass = password.toString();

                if (passConf != null && pass != null && passConf.length() > 5) {

                    if (pass.matches(passConf)) {
                        confirmPass.setError(null);
                        confirmPassHasError =  Boolean.FALSE;
                    } else {
                        confirmPass.setError("Passwords do not match");
                        confirmPassHasError =  Boolean.TRUE;
                    }

                } else {
                    confirmPass.setError("Please fill this field");
                    confirmPassHasError =  Boolean.TRUE;
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
    }
}